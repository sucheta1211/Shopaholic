--------------------------
-- Create Table USER_SEQ
--------------------------
CREATE TABLE SHOP_USERS
(
 USER_ID NUMBER PRIMARY KEY,
 USER_NAME VARCHAR2(100) NOT NULL,
 USER_EMAIL VARCHAR2(100) NOT NULL,
 USER_PWD  VARCHAR2(100) NOT NULL
);
comment on column SHOP_USERS.USER_PWD
  is 'SHA256b Hash of the password.';

----------------------------
-- Create Sequence USER_SEQ
----------------------------
CREATE SEQUENCE USER_SEQ
start with 100000
increment by 1
minvalue 100000
maxvalue 1000000000;

-----------------------------------------------
-- Insert Values in USER_SEQ table!
-- Password will be stored as the SHA256 Hash!
-----------------------------------------------
-- Password@123
INSERT INTO SHOP_USERS VALUES (USER_SEQ.NEXTVAL, 'Prabesh', 'ppp@gmail.com','ff7bd97b1a7789ddd2775122fd6817f3173672da9f802ceec57f284325bf589f');
-- Password@234
INSERT INTO SHOP_USERS VALUES (USER_SEQ.NEXTVAL, 'Sucheta', 'sss@gmail.com','9eed814a8e20c7f7476af869e8f3a833fda3b82c35600ba3846e1a7218482363');
-- Password@345
INSERT INTO SHOP_USERS VALUES (USER_SEQ.NEXTVAL, 'Nikhil' , 'nik@gmail.com','da37a8df1779b4bea0bbff966e9163bf09f2836ab524d5059ce5630ab06c5ded');
-- Password@456
INSERT INTO SHOP_USERS VALUES (USER_SEQ.NEXTVAL, 'Nikita', 'nnn@gmail.com','cee3dc4d010c77d0041bd1e49a39630918559340cc7539d35d318b7f1de8cf02');
commit;