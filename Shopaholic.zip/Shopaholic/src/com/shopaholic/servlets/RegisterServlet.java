package com.shopaholic.servlets;

import static java.lang.System.out;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopaholic.dao.UserDAO;
import com.shopaholic.util.Utility;


@WebServlet("/Register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public RegisterServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// Register a new user !!
		out.println("[SHOPAHOLIC-DEBUG] Inside RegisterServlet");
		out.println("[SHOPAHOLIC-DEBUG] Setting UserDAO");
		
		UserDAO objUserDAO = new UserDAO();
		objUserDAO.setStr_user_name((String)request.getParameter("reg_user_name"));
		objUserDAO.setStr_user_email((String)request.getParameter("reg_user_email"));
		objUserDAO.setStr_user_pwd(Utility.hashify((String)request.getParameter("reg_user_pwd")));
		
		out.println("[SHOPAHOLIC-DEBUG] Validating & Registering new User");
		
		HashMap<?, ?> h_return_map = objUserDAO.insert_new_user();
		
		out.println("[SHOPAHOLIC-DEBUG] Results --> Output Code " + (Integer)h_return_map.get("output_id"));
		out.println("[SHOPAHOLIC-DEBUG] Results --> Output Message " + (String)h_return_map.get("output_message"));
		
		RequestDispatcher view;
		
		if ((Integer)h_return_map.get("output_id") == 1) {
			out.println("[SHOPAHOLIC-DEBUG] Valid ! Registeration Successfull! Forwarding Request to Homescreen!");
			
			request.setAttribute("LoggedInUser", (String)h_return_map.get("output_message"));
			request.setAttribute("nav_item", Utility.NAV_HOME);
			view = request.getRequestDispatcher("jsp/Home.jsp");
			view.forward(request, response);
		
		}else {
			out.println("[SHOPAHOLIC-DEBUG] Registeration NOT Successfull! ! Forwarding Response back to Login.html!");
			
			// Add the script to show the error message.
			response.getWriter().append("<script> function m() {")
								.append("document.getElementById(\"message_reg\").innerHTML")
								.append("= \"")
								.append((String)h_return_map.get("output_message"))
								.append("\"; } </script>");
			
			view = request.getRequestDispatcher("login.html");
			view.include(request, response);
		}
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
