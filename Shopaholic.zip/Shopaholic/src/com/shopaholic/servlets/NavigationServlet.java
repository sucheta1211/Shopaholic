package com.shopaholic.servlets;

import static java.lang.System.out;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopaholic.util.Utility;

@WebServlet("/Navigate")
public class NavigationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public NavigationServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		RequestDispatcher view;
		request.setAttribute("LoggedInUser", (String) request.getParameter("nav_user"));
		
		
		out.println("[SHOPAHOLIC-DEBUG] Inside NavigationServlet");
		out.println("[SHOPAHOLIC-DEBUG] Request Parameter - nav_user ---> " + (String) request.getParameter("nav_user"));
		out.println("[SHOPAHOLIC-DEBUG] Request Parameter - nav_item ---> " + (String) request.getParameter("nav_item"));

		switch ((String) request.getParameter("nav_item")) {

				case (Utility.NAV_HOME): {
					request.setAttribute("nav_item", Utility.NAV_HOME);
					view = request.getRequestDispatcher("jsp/Home.jsp");
					view.forward(request, response);
					break;
				}
				case (Utility.NAV_PRODUCTS): {
					request.setAttribute("nav_item", Utility.NAV_PRODUCTS);
					view = request.getRequestDispatcher("jsp/Products.jsp");
					view.forward(request, response);
					break;
				}
				case (Utility.NAV_PRODUCTDETAIL): {
					request.setAttribute("nav_item", Utility.NAV_PRODUCTDETAIL);
					view = request.getRequestDispatcher("jsp/ProductDetail.jsp");
					view.forward(request, response);
					break;
				}
				case (Utility.NAV_CHECKOUT): {
					request.setAttribute("nav_item", Utility.NAV_CHECKOUT);
					view = request.getRequestDispatcher("jsp/Checkout.jsp");
					view.forward(request, response);
					break;
				}
				case (Utility.NAV_CART): {
					request.setAttribute("nav_item", Utility.NAV_CART);
					view = request.getRequestDispatcher("jsp/Cart.jsp");
					view.forward(request, response);
					break;
				}
				case (Utility.NAV_BLOGS): {
					request.setAttribute("nav_item", Utility.NAV_BLOGS);
					view = request.getRequestDispatcher("jsp/Blogs.jsp");
					view.forward(request, response);
					break;
				}
				case (Utility.NAV_CONTACTUS): {
					request.setAttribute("nav_item", Utility.NAV_CONTACTUS);
					view = request.getRequestDispatcher("jsp/ContactUS.jsp");
					view.forward(request, response);
					break;
				}
				case (Utility.NAV_PAY): {
					view = request.getRequestDispatcher("jsp/Thanks.jsp");
					view.forward(request, response);
					break;
				}
				default: {
					view = request.getRequestDispatcher("jsp/404.jsp");
					view.forward(request, response);
				}
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}