package com.shopaholic.servlets;

import static java.lang.System.out;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopaholic.dao.UserDAO;
import com.shopaholic.util.Utility;


@WebServlet("/Login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public LoginServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// Validate the User!!
		out.println("[SHOPAHOLIC-DEBUG] Inside LoginServlet");
		out.println("[SHOPAHOLIC-DEBUG] Setting UserDAO");
		
		UserDAO objUserDAO = new UserDAO();
		objUserDAO.setStr_user_email((String)request.getParameter("log_user_email"));
		objUserDAO.setStr_user_pwd(Utility.hashify((String)request.getParameter("log_user_pwd")));
		
		out.println("[SHOPAHOLIC-DEBUG] Validating User");
		
		HashMap<?, ?> h_return_map = objUserDAO.validate_user();
		
		out.println("[SHOPAHOLIC-DEBUG] Results --> Output Code " + (Integer)h_return_map.get("output_id"));
		out.println("[SHOPAHOLIC-DEBUG] Results --> Output Message " + (String)h_return_map.get("output_message"));
		
		RequestDispatcher view;
		
		if ((Integer)h_return_map.get("output_id") == 1) {
			out.println("[SHOPAHOLIC-DEBUG] Valid ! Forwarding Request to Homescreen!");
			
			request.setAttribute("LoggedInUser", (String)h_return_map.get("output_message"));
			request.setAttribute("nav_item", Utility.NAV_HOME);
			view = request.getRequestDispatcher("jsp/Home.jsp");
			view.forward(request, response);
		
		}else {
			out.println("[SHOPAHOLIC-DEBUG] InValid User! Forwarding Response to back Login.html!");
			
			// Add the script to show the error message.
			response.getWriter().append("<script> function m() {")
								.append("document.getElementById(\"message_log\").innerHTML")
								.append("= \"")
								.append((String)h_return_map.get("output_message"))
								.append("\"; } </script>");
			
			view = request.getRequestDispatcher("login.html");
			view.include(request, response);
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
