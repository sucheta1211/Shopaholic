package com.shopaholic.dao;


import java.util.HashMap;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import com.shopaholic.util.DBConnect;

public class UserDAO {

	private String str_user_name;
	private String str_user_email;
	private String str_user_pwd;

	public String getStr_user_name() {
		return str_user_name;
	}

	public void setStr_user_name(String str_user_name) {
		this.str_user_name = str_user_name;
	}

	public String getStr_user_email() {
		return str_user_email;
	}

	public void setStr_user_email(String str_user_email) {
		this.str_user_email = str_user_email;
	}

	public String getStr_user_pwd() {
		return str_user_pwd;
	}

	public void setStr_user_pwd(String str_user_pwd) {
		this.str_user_pwd = str_user_pwd;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public HashMap<?, ?> insert_new_user() {

		Connection con = null;
		CallableStatement cStmt = null;

		HashMap outputMap = new HashMap();
		try {

			con = DBConnect.getConnection();
			cStmt = con.prepareCall("{call PKG_SHOP_UTIL.insert_new_user(?, ?, ?, ?, ?)}");
			cStmt.setString(1, this.getStr_user_name());
			cStmt.setString(2, this.getStr_user_email());
			cStmt.setString(3, this.getStr_user_pwd());
			cStmt.registerOutParameter(4, Types.INTEGER);
			cStmt.registerOutParameter(5, Types.VARCHAR);
			cStmt.executeUpdate();

			outputMap.put("output_id", (Integer) cStmt.getInt(4));
			outputMap.put("output_message", (String) cStmt.getString(5));

		} catch (Exception e) {

			e.printStackTrace();
		}

		finally {
			try {
				if (cStmt != null)
					cStmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return outputMap;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public HashMap<?, ?> validate_user() {

		Connection con = null;
		CallableStatement cStmt = null;

		HashMap outputMap = new HashMap();
		try {

			con = DBConnect.getConnection();
			cStmt = con.prepareCall("{call PKG_SHOP_UTIL.validate_user(?, ?, ?, ?)}");
			cStmt.setString(1, this.getStr_user_email());
			cStmt.setString(2, this.getStr_user_pwd());
			cStmt.registerOutParameter(3, Types.INTEGER);
			cStmt.registerOutParameter(4, Types.VARCHAR);
			cStmt.executeUpdate();

			outputMap.put("output_id", (Integer) cStmt.getInt(3));
			outputMap.put("output_message", (String) cStmt.getString(4));

		} catch (Exception e) {

			e.printStackTrace();
		}

		finally {
			try {
				if (cStmt != null)
					cStmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return outputMap;
	}
}
