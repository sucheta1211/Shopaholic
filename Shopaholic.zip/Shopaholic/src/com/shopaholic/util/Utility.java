package com.shopaholic.util;

import static java.lang.System.out;
import java.security.MessageDigest;
import javax.xml.bind.DatatypeConverter;

public class Utility {

	/*
	 * Specify Static Constants.
	 * 
	 */

	public static final String NAV_HOME = "home";
	public static final String NAV_PRODUCTS = "products";
	public static final String NAV_PRODUCTDETAIL = "productdetails";
	public static final String NAV_CHECKOUT = "checkout";
	public static final String NAV_CART = "cart";
	public static final String NAV_BLOGS = "blogs";
	public static final String NAV_CONTACTUS = "contactus";
	public static final String NAV_WISHLIST = "wishlist";
	public static final String NAV_PAY = "pay";
	public static final String NAV_404 = "404";
		
	/*
	 * This Utility function returns a SHA256 hash of the input String!
	 * 
	 */

	public static String hashify(String strString) {

		String strResult = null;

		try {

			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			byte[] hash = digest.digest(strString.getBytes("UTF-8"));
			strResult = DatatypeConverter.printHexBinary(hash);

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		out.println("[SHOPAHOLIC-DEBUG] SHA256 Digest --> " + strResult);
		return strResult;
	}

}
