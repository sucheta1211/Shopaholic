package com.shopaholic.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class DBConnect {

	private static Statement stmt;
	private static ResultSet rs;
	private static Connection con;
	

	public static Connection getConnection() throws ClassNotFoundException, SQLException {

		
		Class.forName("oracle.jdbc.driver.OracleDriver");				// Register Driver
		
		/*
		 *  Connection to Pluggable Database(s) should be made via ServiceName instead of SID
		 *  jdbc:oracle:thin:@[HOST]:[PORT]/SERVICE
		 *
		 */
		
		return DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/orclpdb", "HR", "password");

	}

	private ArrayList<String> executeStatement(String strSql) {

		ArrayList<String> arrOutputList = new ArrayList<String>();

		try {

			con = getConnection();
			stmt = con.createStatement();
			rs = stmt.executeQuery(strSql);

			while (rs.next()) {

				arrOutputList.add(rs.getString(1));
			}

		} catch (SQLException | ClassNotFoundException e) {

			e.printStackTrace();
		}

		finally {

			try {

				rs.close();
				stmt.close();
				con.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}

		}
		return arrOutputList;

	}

}